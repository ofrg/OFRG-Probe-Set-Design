#!/usr/bin/perl

print "#include \"simann.h\"\n";
print "#include <stdio.h>\n";
print "#include <stdlib.h>\n";
print "#include <string.h>\n";
print "#include <stddef.h>\n";

print "void\n";
print "run_tests (void)\n";
print "{\n";



my @candidate_probes=qw(ATTG AGTG ACTC ACTG ATGG ATCG ATAG TTTG GTTG CTTG);
my %fingerprints=(ATTG =>'1 0 0 1 0 1 0 1 0 1 1 0',
                  AGTG =>'1 0 0 1 0 1 0 1 0 1 1 0',
                  ACTC =>'0 1 0 0 1 0 1 0 1 0 1 0',
                  ACTG =>'1 0 0 1 0 1 0 1 0 1 1 0',
                  ATGG =>'1 0 0 1 0 1 0 1 0 1 1 0',
                  ATCG =>'0 1 1 0 1 0 1 0 1 0 1 0',
                  ATAG =>'1 0 0 0 0 0 0 0 0 0 1 0',
                  TTTG =>'0 0 0 0 0 0 0 0 0 0 1 0',
                  GTTG =>'1 1 1 1 1 1 1 1 1 1 1 0',
                  CTTG =>'0 0 0 0 0 0 0 0 0 0 0 0',
                  );

print "number_clones=12;number_candidate_probes=10;number_probes=10;max_linear_response=1;\n";
print "init_packed_occurrences(number_clones, number_candidate_probes);\n";
print "probes *solution;\n";


my $number_clones=scalar split / /, $fingerprints{$candidate_probes[0]};
my $number_probes=scalar @candidate_probes;


my $probe=0;
for my $p (@candidate_probes) {
    my $clone=0;
    for my $f (split / /, $fingerprints{$p}) {
        print "write_packed_occurrences( $clone, $probe, $f);\n";
        ++$clone;
    }
    ++$probe;
}




my $probe=0;
for my $p (@candidate_probes) {
    my $clone=0;
    for my $f (split / /, $fingerprints{$p}) {
        print "if (read_packed_occurrences( $clone, $probe) != $f) {
               printf(\"Error in reading ( $clone, $probe)\\n\");
               printf(\"Read %d instead of $f\\n\", read_packed_occurrences( $clone, $probe));
};\n";
        ++$clone;
    }
    ++$probe;
}

print "solution = (probes *) calloc(". scalar keys (%fingerprints) .", sizeof(probes));\n";

for (my $i=0; $i<scalar keys %fingerprints; $i++) {
    print "solution[".$i."]=".$i.";\n";
}


for (my $clone=0; $clone<$number_clones; $clone++) {
    my $real_fingerprint=0;
    for (my $p=0; $p<$number_probes; $p++) {
        my @f=split / /, $fingerprints{$candidate_probes[$p]};
        $real_fingerprint=2*$real_fingerprint+$f[$clone];
    }
    print "if (fingerprint(solution, $clone) != $real_fingerprint) {
               printf(\"Error in computing fingerprint ($clone)\\n\");
               printf(\"Read %lld instead of $real_fingerprint\\n\", fingerprint(solution, $clone));
};\n";
}




for (my $clone=0; $clone<$number_clones; $clone++) {
    my $good=$real_fingerprint[$clone];
}


print "printf(\"Completed\\n\");\n";
print "}\n";
