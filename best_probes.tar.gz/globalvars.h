/** Global Variables

    The cost of the actual solution
*/

costs gcost;

/**

   pointer to the matrix of the occurrences of each probe in each clone
*/
unsigned short int *occurrences;
/**
   number of probes to be computed, number of clones received. number of
   candidate probes received, length of the probes to compute, alphabet
   of the clones, number of cols of the occurrences matrix,
*/
unsigned int number_probes;
unsigned int number_good_probes;
unsigned int number_clones;
unsigned int number_candidate_probes;
unsigned int length_probes;

costs penalties[HIERARCHY_LEVELS+1];
/* penalty for the number of fingerprint with a same OTU */
costs penalty_otu;

/**
   discriminating_info is an array of pointers to the  arrays containing, for each clone,
   its current fingerprint as well as information about phylum, genus
   and otu.
*/
features *discriminating_info;
clones * sorted_clones;

unsigned int number_packed_probes;
unsigned int blocks_per_fingerprint; // the number of blocks for each fingerprint
unsigned int block_length; // how many probes can be encoded in a single block?
                           // that is, the number of entries in a block
unsigned int max_linear_response; // binary (1) or non-binary (>1) distinguishability

/*
 * alphabet_size**length_probes,q
 */
unsigned int max_search_space;

/**
expanded_probe is the array containing the extended
representation of each probe~\ref{extended}. We recall that each probe
$p$
in a solution ranges from $0$ to number_candidate_probes-1, while
  expanded_probe[$p$] ranges from $0$ to max_search_space-1.
  */
  char **expanded_probe;
/**
   We initialize alphabet and max_search_space.
*/
unsigned int beta;



/*
  Important filenames
*/
char *bad_probes_file_name;
char *good_probes_file_name;
char *input_matrix_file_name;
