#ifndef _SIMANN_INCLUDED_
#define _SIMANN_INCLUDED_
#define EXPECTED_APPROXIMATION          1.2
#define PROBABILITY_APPROXIMATION       .9
#define NEIGHBORS_FOR_INITIAL_SOLUTION 100
#define PROBABILITY_OF_GOOD_NEIGHBOURS   0.2
#define PROBABILITY_FINAL   0.01
#define QUALITY_SOLUTION 0.01
#define MINIMUM_TEMPERATURE 0.006
#define TOTAL_DECREMENTS 100000


#define MAX_LENGTH_STRING           32000
#define MAXIMUM_NUMBER_PROBES_IN_SOLUTION   100


/*
 * how many probes we can pack into an integer
 */
#define MAX_CLONE_LENGTH        5000
#define MAX_ALPHABET_SIZE       4


/*
  Now the occurrences matrix is a simple 2-dimensional matrix
  */
#define read_packed_occurrences(clone, probe) occurrences[clone*number_candidate_probes+probe]
#define write_packed_occurrences(clone, probe, value) occurrences[clone*number_candidate_probes+probe]=value


#define NUMBER_COOLINGS 1000
/* this param must be transformed into a command-line argument
 */
/**
[[MAX_POSSIBLE_COST]] is an upper bound on the
maximum cost of any feasible solution, which is the highest hill that
the algorithm might eventually face.
*/
#define MAX_POSSIBLE_COST (number_clones*number_clones*penalties[0])
/* splint complains about varargs in defines */
#ifndef S_SPLINT_S
    #ifndef NDEBUG
        #define PRINT_LOGn(verbiage_level,format, ...) if (VERBOSE>=verbiage_level) {fprintf (stderr, "LOG %d at %s  line %d\n",verbiage_level,__FILE__, __LINE__); fprintf (stderr, format, ## __VA_ARGS__); }
        #define APPEND_LOGn(verbiage_level,format, ...) if (VERBOSE>=verbiage_level) {fprintf (stderr, format, ## __VA_ARGS__); }
    #else
        #define PRINT_LOGn(verbiage_level,format, ...) ;
        #define APPEND_LOGn(verbiage_level,format, ...) ;
    #endif
    #define PRINT_FATAL(format, ...) fprintf (stderr, "FATAL error at %s  line %d\n",__FILE__, __LINE__); fprintf (stderr, format, ## __VA_ARGS__) ; exit(EXIT_FAILURE)
#else
    #define PRINT_LOGn ;//
    #define PRINT_FATAL ;//
#endif


/* How many levels (genus, phylum, otu) there are */
#define HIERARCHY_LEVELS 3

typedef unsigned int fingerprint_type;
typedef unsigned int feature_type;
typedef unsigned int clones;
typedef unsigned int probes;
typedef probes * t_solutions;
typedef unsigned long long int hash_indices;
typedef unsigned long long int cost_type;
typedef long long int costs;

typedef struct {
    feature_type hierarchy[HIERARCHY_LEVELS];
    fingerprint_type       * fingerprints;
} features;

/**
 * List of functions prototypes
 */

unsigned int read_info_from_feature(const clones, int);
void decrease_temperature(float *);
void determine_initial_solution(t_solutions);
float determine_initial_temperature(void);
fingerprint_type fingerprint(t_solutions, clones);
void int2str(char*, unsigned int);
float lookup_exp(float, float);
void neighbor_probe(t_solutions);
void probe2str(char*, probes);
int random_range(int, int);
void scan_input(void);
unsigned int str2int(char*);
unsigned int which_symbol(char);
void init_packed_occurrences();
fingerprint_type fingerprint_single_block(t_solutions, clones, unsigned int);
void init_features(void);
void write_info_from_feature(const clones, unsigned int, feature_type);
unsigned int read_fingerprint(clones, probes);






/*
  Optimization according to Ulrich Drepper
  http://lwn.net/Articles/255364/
*/
long __builtin_expect(long EXP, long C);
#define unlikely(expr) __builtin_expect(!!(expr), 0)
#define likely(expr) __builtin_expect(!!(expr), 1)

// Include global variables
#include "globalvars.h"
#endif
