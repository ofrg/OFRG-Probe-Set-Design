#!/usr/bin/perl -w
use strict;
use Getopt::Long ;              #qw(:config debug);
use List::Util qw(max);
use List::MoreUtils qw(all any false none true uniq);

my $max_hierarchy=3;
my $matrix_file;
my $clones_file;
my %penalties=();
my $penalties_otu;
my $help;
our %fingerprints_by_clone=();
our %fingerprints_by_otu=();


my @levels=( 'CLONE', 'OTU', 'GENUS', 'PHYLUM' );

GetOptions (
            'help' => \$help,
            'matrix_file=s' => \$matrix_file,
#            'clones_file=s' => \$clones_file,
            'penalty_standard=i' => \$penalties{CLONE},
            'penalty_otu=i' => \$penalties{OTU},
            'penalty_phylum=i' => \$penalties{PHYLUM},
            'penalty_genus=i' => \$penalties{GENUS},
            'penalty_fingerprints_in_otu=i' => \$penalties_otu,
           );

if (defined $help or not defined $penalties{CLONE} or not defined $penalties{OTU} or not
    defined $penalties{GENUS} or not defined $penalties{PHYLUM}  or not defined $penalties_otu
    or not defined $matrix_file) {
    print   "This program receives the file computed by best_probes (the Simulated Annealing program)\n".
        "containing the probe sets, and outputs various statistics for each probe sets read\n".
            "The program accepts the following options:\n".
            "matrix_file (required)): the occurrences matrix used by the SA program\n".
            "penalty_standard (required): the cost of a pair of clones with same fingerprint\n".
            "penalty_otu (required): the cost of a pair of fingerprints with same OTU\n".
            "penalty_phylum (required): the cost of a pair of fingerprints with same phylum\n".
            "penalty_genus (required): the cost of a pair of fingerprints with same genus\n".
            "penalty_fingerprints_in_otu (required): the cost of a pair of fingerprints with same OTU\n".
                "\nAn invocation of the program is something like:\n".
            "results2stats.pl --matrix_file=matrix.txt --penalty_standard=10 --penalty_otu=1 --penalty_phylum=2 --penalty_genus=3  output_file\n";
    exit;
}



# The perl script \texttt{results2stats.pl} receives the probes
# output by the program
# and outputs the clusters with various statistics.


# Let's start by reading (from standard input) the probes previously computed by the simulated
# annealing algorithm

# @experiments contains a reference to the list of probes of each experiment;
my @experiments=();
my @values_experiment=();


my $probesA;
my $num_experiment=0;

while (my $l=<>) {
    chomp $l;
    if ($l=~/^Final solution has value.*?(\d+)$/) {
        push @values_experiment, $1;
        # a new experiment begins
        $probesA=[];
        push(@experiments, $probesA);

        next;
    }
    $l=~s/.*\=//;
    push (@$probesA, $l) if ($l=~/^[ACGT]+$/);
}



# Now compute the stats for each experiment
for my $experiment (@experiments) {
    my @probes=sort  @$experiment;
    my $value_experiment=shift @values_experiment;

    ++$num_experiment;
    print "***\n";
    print "***\n";
    print "*** RESULTS OF EXPERIMENT $num_experiment (out of ".scalar @experiments.")\n";
    print "***\n";
    print "***\n";
    if (check_duplicated_probes(@probes)) {
        print "WARNING: some probes are duplicated\n";
    }


    %fingerprints_by_clone=();
    my ($genus, $phylum, $otu)=('','','');
    my $number_ones=0;
    my %number_ones_by_cardinality=();


    my $length_probes=length($probes[0]);

    my %fingerprints=();
    for my $current_probe (@probes) {
        #%fingerprints: keys are probes, values are refs to annonymous arrays
        #containing the (per clone) fingerprint for the current probe
        $fingerprints{$current_probe}= [split(/ /,find_fingerprint_probe($current_probe) )];
        #running total of 1s (per probe per clone) for the probe set
        $number_ones+=true {$_ == 1} @{$fingerprints{$current_probe}};
    }

    # Now read the matrix file, in order to find the fingerprints of genus, phylum, otu
    open (MF, "<", $matrix_file)
        or die ("Cannot open $matrix_file\n");
    while (my $l=<MF>) {
        chomp $l;
        $phylum=$genus;
        $genus=$otu;
        $otu=$l;
    }

    my @genuss=split(/ /,$genus);
    my @phylums=split(/ /,$phylum);
    my @otus=split(/ /,$otu);
    close(MF);





    #
    # in %fingerprints_by_clone, which is a hash keyed by the clone number,
    # there is the fingerprint of the clone (relative to the solution computed by the
    # SA algorithm, as well as the info regarding genus, phylum and otu
    #
    my $number_clones=0;
    while (scalar @otus > 0) {
        $number_clones++;
        my @fingerprint_list=();
        # $f cycles through the probes in this probe set
        for my $f (sort keys %fingerprints) {
            # $v is getting the 1 or 0 for the probe/clone SA result
            my $v=shift @{$fingerprints{$f}};
            # @fingerprint_list holds the fingerprint for the current clone
            push @fingerprint_list, $v;
        }
            #...then it is inserted into %fingerprints_by_clone
        my $next_genus=shift @genuss;
        my $next_phylum=shift @phylums;
        my $next_otu=shift @otus;
        my $next_fingerprint = join ('', @fingerprint_list );
        $fingerprints_by_clone{$number_clones}= {
                                                 FINGERPRINT => $next_fingerprint,
                                                 GENUS       => $next_genus,
                                                 PHYLUM      => $next_phylum,
                                                 OTU         => $next_otu,
                                                };

        #...then it is inserted into %fingerprints_by_otu
        unless (exists $fingerprints_by_otu{$next_otu}) {
            $fingerprints_by_otu{$next_otu}=[ $next_fingerprint ];
        } else {
            add_if_not_present($fingerprints_by_otu{$next_otu}, $next_fingerprint);
        }
    }



    my @sorted_clones=sort { compare_complete_fingerprints($a,$b) } (1 .. $number_clones);
    #
    # Now @sorted_clones clusters together clones sharing a common fingerprint
    #


    #get a "master list" of all unique fingerprints (for the clones)
    #for each (unique) fingerprint, record the otus, genera & phyla in which it occurs
    my %taxa_by_fingerprint=();
    #$taxa_by_fingerprint{$fingerprint}= {
    #                                            OTU         => \@otus_with_this_fingerprint,
    #                                            PHYLUM       => \@phyla_with_this_fingerprint,
    #                                            GENUS      => \@genera_with_this_fingerprint
    #                                           };
    my %fingerprints_by_taxa=(
                              OTU => {}, # for each OTU, list the fingerprints
                              GENUS => {},
                              PHYLUM => {},
                             );

    # In the following, it is not necessary to process the clones in some order.
    foreach my $clone (@sorted_clones) {
        my ($fingerprint,$genus,$phylum,$otu)=(
                                               $fingerprints_by_clone{$clone}->{FINGERPRINT},
                                               $fingerprints_by_clone{$clone}->{GENUS},
                                               $fingerprints_by_clone{$clone}->{PHYLUM},
                                               $fingerprints_by_clone{$clone}->{OTU}
                                              );
        unless (exists $taxa_by_fingerprint{$fingerprint}) {
            $taxa_by_fingerprint{$fingerprint}= {
                                                 CLONE       => [ $clone  ],
                                                 OTU         => [ $otu    ],
                                                 PHYLUM      => [ $phylum ],
                                                 GENUS       => [ $genus  ],
                                                };
        } else {
            push(@{$taxa_by_fingerprint{$fingerprint}->{CLONE}}, $clone);
            add_if_not_present($taxa_by_fingerprint{$fingerprint}->{OTU}, $otu);
            add_if_not_present($taxa_by_fingerprint{$fingerprint}->{PHYLUM}, $phylum);
            add_if_not_present($taxa_by_fingerprint{$fingerprint}->{GENUS}, $genus);
        }


        for my $level (qw/OTU GENUS PHYLUM/) {
            my $f=$fingerprints_by_clone{$clone}->{FINGERPRINT};
            my $v=$fingerprints_by_clone{$clone}->{$level};
            my $href=$fingerprints_by_taxa{$level};
            if (exists $href->{$v}) {
                add_if_not_present($href->{$v}, $f);
            } else {
                $href->{$v} = [ $f ];
            }
        }
    }

    my $cost=0;
    print "Information read from the computed solution\n";
    print "Clone\t OTU\t Genus\t Phylum\t Fingerprint\n";
    for my $clone (sort {$a <=> $b} keys %fingerprints_by_clone) {
        print join (" \t",
                    $clone,
                    $fingerprints_by_clone{$clone}->{OTU},
                    $fingerprints_by_clone{$clone}->{GENUS},
                    $fingerprints_by_clone{$clone}->{PHYLUM},
                    $fingerprints_by_clone{$clone}->{FINGERPRINT}
                    )."\n";
    }


    # Now compute the output that can be used for debugging purposes
    # 1. for each fingerprint, detail the clones with such fingerprint
    print "Information 2\n";
    print "End of Fingerprint Clones\n";

    # 2. for each fingerprint, detail the  OTU, phylum, etc.,  with such fingerprint
    for my $level (@levels) {
        my $partial=0;
        print "Fingerprint\t Number\t $level \n";
        my $np=0;
        my $checksum=0;
        foreach my $fingerprint (sort keys %taxa_by_fingerprint) {
            my @l=@{$taxa_by_fingerprint{$fingerprint}->{$level}};
            $np += num_pairs(scalar(@l));
            print "$fingerprint\t ". scalar(@l). "\t ".join(',',@{$taxa_by_fingerprint{$fingerprint}->{$level}})."\n";
        }
        print "Number of pairs: ". $np ." with cost ". $np*$penalties{$level}  ."\n";
        $partial+=$np*$penalties{$level};
        $cost+=$partial;
        print "Total cost: $cost ($partial)\n";
    }
    print "End Information 2\n\n";


    # 3. For each OTU, detail the fingerprints appearing in such OTU
    print "Information 3\n";

    for my $level (qw/OTU/) {
        my $partial=0;
        my $href=$fingerprints_by_taxa{$level};
        print "Level = $level\n";
        print "Info\t Number\t Fingerprint\n";
        my $np=0;
        for my $t (sort {$a <=> $b} keys %$href) {
            my @l=@{$href->{$t}};
            $np += num_pairs(scalar(@l));
            print "$t\t ". scalar(@l). "\t ".join(',',@{l})."\n";
        }
        print "Number of pairs: ". $np ." with cost ". $np*$penalties_otu  ."\n";
        $partial+=$np*$penalties_otu;
        $cost+=$partial;
        print "Total cost: $cost ($partial)\n";
    }
    print "End Information 3\n\n";


    # The cost is computed.
    # Now it's time for some stats.


# According to Paul July 11 the ones that are interesting are:
#    This is in flux somewhat as most of the stats are exploratory.
# However, the most likely ones I will use are:
# 1 - value of solution given in probe set (DONE)
# 2 - total number of unique fingerprints (DONE)
# 3 - total number of unique fingerprints that map to (can be found in) one and only one OTU.
# 4 - ratio: no. 3 / no. 2
# 5 - print each probe in current probe set on one line, separated by tabs (I may look for probes that show up often in good probe sets)
# 6 - printout of the distribution of 1s per unique fingerprint

    print "Number of unique fingerprints: ". scalar (keys %taxa_by_fingerprint) ."\n";
    print "Number of unique fingerprints mapping to exactly one OTU: ".
        scalar (grep {scalar @{$taxa_by_fingerprint{$_}->{OTU}} == 1 } keys %taxa_by_fingerprint) ."\n";
    print "Ratio of the last two values: ".
        scalar (grep {scalar @{$taxa_by_fingerprint{$_}->{OTU}} == 1 } keys %taxa_by_fingerprint) /
            scalar (keys %taxa_by_fingerprint)."\n";

    print "Probes computed on one line (separated by tabs)\n";
    print join("\t", sort @probes)."\n";

    # Compute the number of ones of each fingerprint, and their frequencies.
    for my $f (keys %taxa_by_fingerprint) {
        my $num_ones = true {$_ == 1} (split //, $f);
        $number_ones_by_cardinality{true {$_ == 1} (split //, $f)}++;
    }



    # Output the frequencies on the number of ones in each fingerprint

    print "How many fingerprints have a certain number of 1s\n";
    print "Number 1s   Frequencies\n";
    for my $c (sort {$a <=> $b} keys %number_ones_by_cardinality) {
        printf("%9d    %10d\n", $c, $number_ones_by_cardinality{$c} );
    }
    print "\n";

    print "Objective function value      : ". $cost. "\n";
    print "Expected  function value      : ". $value_experiment. "\n";
    print "Possible error in computing the function value: $value_experiment ($cost) diff=".
        ($value_experiment-$cost) ."\n" unless ($cost == $value_experiment);
    print "\n\n\n";
}


sub find_fingerprint_probe {
    my $probe=shift;

    # Now read the matrix file, looking for all probes computed by the algorithm
    open (MF, "<", $matrix_file)
        or die ("Cannot open $matrix_file\n");

    while (my $l=<MF>) {
        chomp $l;
        next unless ($l=~/^[ACGT]*$/); # Don't process lines not encoding probes
        my $f=<MF>;#the per clone fingerprint
        chomp $f;
        if ($l eq $probe) {
            if ($f=~/[ACGT]/) {
                die "Error 1: $f:$l:$probe *\n";
            }
            close MF;
            return $f;
        }
    }
    die "Could not find probe $probe in $matrix_file \n";
}

sub mergesort_clones {
    my $compare_sub;
    my @clones=@_;
    my $number_elements=scalar @clones;
    if ($number_elements < 2) {
        return @clones;
    }
    my @listA=mergesort_clones($compare_sub,splice @clones, int($number_elements/2));
    my @listB=mergesort_clones($compare_sub,@clones);

    my @sorted_list=();
    while (scalar @listA >0 and scalar @listB >0  ) {
        if ($compare_sub->($listA[0], $listB[0]) <0) {
            push (@sorted_list, shift @listB);
        } else {
            push (@sorted_list, shift @listA);
        }
    }
    return (@sorted_list, @listA, @listB);
}


sub compare_complete_fingerprints {
    my $a=shift;
    my $b=shift;
    my @featuresA=(split(//, $fingerprints_by_clone{$a}->{FINGERPRINT}),
                  $fingerprints_by_clone{$a}->{GENUS},
                  $fingerprints_by_clone{$a}->{PHYLUM},
                  $fingerprints_by_clone{$a}->{OTU});
    my @featuresB=(split(//, $fingerprints_by_clone{$b}->{FINGERPRINT}),
                  $fingerprints_by_clone{$b}->{GENUS},
                  $fingerprints_by_clone{$b}->{PHYLUM},
                  $fingerprints_by_clone{$b}->{OTU});

    for my $va (@featuresA) {
        my $vb=shift @featuresB;
        if ($va < $vb) {
            return -1;
        } elsif ($va > $vb) {
            return 1;
        }
    }
    return 0;
}

sub compare_to_sort_OTU {
    my $a=shift;
    my $b=shift;

    my $va=$fingerprints_by_clone{$a}->{OTU};
    my $vb=$fingerprints_by_clone{$b}->{OTU};
    if ($va < $vb) {
        return -1;
    } elsif ($va > $vb) {
        return 1;
    }


    my @featuresA=(split(//, $fingerprints_by_clone{$a}->{FINGERPRINT}));
    my @featuresB=(split(//, $fingerprints_by_clone{$b}->{FINGERPRINT}));
    for my $va (@featuresA) {
        my $vb=shift @featuresB;
        if ($va < $vb) {
            return -1;
        } elsif ($va > $vb) {
            return 1;
        }
    }
    return 0;
}

sub check_sorted_clones {
    my @clones=@_;
    my $prev=shift @clones;
    for my $clone (@clones) {
        if (($fingerprints_by_clone{$prev}->{FINGERPRINT} <=>
             $fingerprints_by_clone{$clone}->{FINGERPRINT}) > 0) {
            $prev=$clone;
            print $prev.":".$clone.":".$fingerprints_by_clone{$prev}->{FINGERPRINT}.":".$fingerprints_by_clone{$clone}->{FINGERPRINT};
            die "Error in sorting fingerprints_by_clone: statistics incorrect\n";
        }
        $prev=$clone;
    }
}


sub check_duplicated_probes {
    my %t=();
    for $a (@_) {
        return 1 if (defined $t{$a});
        $t{$a}=0;
    }
    return 0;
}

sub num_pairs {
    my $n=shift;
    return $n*($n -1)/2;
}


# Gets a reference to a list and a value.
# Adds the value to the list only if it's not already there.
sub add_if_not_present {
    my $aref=shift;
    my $v=shift;
    if (defined @$aref and 0<scalar @$aref) {
        if (none {$v eq $_} @$aref) {
            # The condition above enforces the insert if the list is empty
            push (@$aref, $v);
        }
    } else {
        $aref = [ $v ];
    }
}
