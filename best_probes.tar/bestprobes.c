/**
   \title{Algorithm for Probe Selection}
   \author{J.~Borneman, M.~Chrobak, G.~Della Vedova, A.~Figueroa,
   T.~Jiang}
   \maketitle
   This program receives as arguments the number of probes to compute,
   the number of clones, the steepness parameter and the number of
   experiments to run. In standard input it receives the filename of the matrix containing
   how many times does each candidate probe appears in each clone.

   Note that we are always dealing with a minimization problem

   Each probe is a string over DNA alphabet, which is then translated
   into  an integer from $0$ to $4^k-1$ for probes of length $k$. We need
   a compact numbering of the probe set, ranging from $0$ to the number of
   probes. Hence in Representation of Probes we introduce the array
   expanded_probe which associates
   to a \emph{probe} its expanded value. So for each candidate probe
   there are three different representations:
   \begin{itemize}
   \item
   as a string over the alphabet \texttt{A,C,G,T}
   \item
   as an integer from $0$ to $4^k-1$, that is the \emph{extended probe}
   \item
   as an integer from $0$ to $|P|-1$, that is the \emph{candidate probe}
   \end{itemize}
   Usually we will deal with the third representation.


   In this new algorithm we store the number of clones with a given
   fingerprint in an array. Since such array can be thought of as a hash,
   the function that updates such array is called update_hash. The
   same function also updates the value gcost of the cost of the
   current solution.


   Moreover we must employ a packed representation of the occurrences matrix.
   Some steps of the algorithm must be implementation specific, most
   notably finding a neighbor solution, the cooling scheme and
   how to evaluate the cost of an actual solution. The cooling scheme is
   the one shown in the description of the algorithm.

   This program exploits the simulated annealing technique, hence it is
   of the following form, as described in \cite{ismb2001}, where $P$ is
   the set of candidate probes and $C$ is the set of clones:

   {\bf Algorithm} \textsc{SimulatedAnnealing}$(P,C,k)$\        \
   Initialize $S$ to be a set of $k$ random probes from $P$;\   \
   $t$:= initial temperature;\                                  \
   \textbf{repeat} \\,
   $~~$ $S'$:= a random neighbor of $S$;\\
   $~~$ $S:=S'$ with probability $\min\{ 1 ,$exp$(\frac{ |\Delta_S| - |\Delta_{S'}|}{t}) \}$;\ \
   $~~$ Set $t:= \frac{\beta t}{\beta+t}$;\                             \
   \textbf{until} $t\leq$final temperature;\                            \
   \textbf{return$(S)$};

   Some steps of the algorithm must be implementation specific, most
   notably finding a neighbor solution, the cooling scheme and
   how to evaluate the cost of an actual solution. The cooling scheme is
   the one shown in the description of the algorithm.

   The following function neighbor_solution receives a solution
   and computes one of its neighbor solutions. It updates the values of the hash
   hash_cost. A solution is
   considered neighbor of itself. In fact
   if the solution computed is not feasible, the original solution is retained.


*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <float.h>
#include <math.h>
#include <time.h>
#include <limits.h>
#include <errno.h>
#include <stdbool.h>
#include "simann.h"
#include "options.h"
/* If we use autoconf.  */
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif
/* Check for configure's getopt check result.  */
#ifndef HAVE_GETOPT_LONG
#include "getopt.h"
#else
#include <getopt.h>
#endif
#include "tests.h"


unsigned int
neighbor_solution(t_solutions my_solution)
{
    unsigned int new_probe, which_probe=0, old_probe=my_solution[which_probe];
    unsigned int test,k;
    #ifndef NDEBUG
        unsigned int number_iterations_n=0;
    #endif
    do {
#ifndef NDEBUG
        if(++number_iterations_n > 100)
            PRINT_LOGn(0,"%6d iterations in neighbor_solution\n", number_iterations_n);
#endif
        my_solution[which_probe]=old_probe;
        test=0;
        new_probe = (unsigned int) random_range(0, (int) number_candidate_probes - 1);
        which_probe =  number_good_probes + (unsigned int) random_range(0, (int) number_probes - number_good_probes - 1);
        old_probe=my_solution[which_probe];
        my_solution[which_probe]=new_probe;
        for (k=0; k< number_probes; k++) {
            if (my_solution[k]==new_probe)
                test++;
        }
    } while (test > 1);
    return(which_probe);
}


void
print_info_clone(const clones c, unsigned int debug_level)
{
    APPEND_LOGn(1,"Fingerprint ");
    for(unsigned int b=0;b<blocks_per_fingerprint;b++) {
        APPEND_LOGn(1,"%12u ", discriminating_info[c].fingerprints[b]);
    }
    APPEND_LOGn(1," Features: ");
    for(unsigned int level=1;level<=HIERARCHY_LEVELS;level++) {
        APPEND_LOGn(1,"%4d ", read_info_from_feature(c,level));
    }
}



void
print_info(const clones c, const t_solutions s, unsigned int debug_level)
{
    APPEND_LOGn(debug_level,"print_info: %6d ", c );
    for(probes p=0;p<number_candidate_probes;p++) {
        APPEND_LOGn(debug_level,"%1d", read_packed_occurrences(c,p));
    }
    APPEND_LOGn(debug_level," ");
    print_info_clone(c,debug_level);
    APPEND_LOGn(debug_level,"\n");
}


void
print_info_sorted_clones(const clones c1, const clones c2, unsigned int debug_level)
{
    APPEND_LOGn(debug_level,"N clone fingerprint features\n");
    for(clones c=c1;c<=c2;c++) {
        APPEND_LOGn(debug_level,"%6u %6u ", c, sorted_clones[c]);
        print_info_clone(sorted_clones[c],debug_level);
        APPEND_LOGn(debug_level,"\n");
    }
}


/**
   And now it is time to define the functions operating on the features.
   Besides the clones to be compared, the function compare_discriminating_info
   receives a pointer to an array stating which discriminating_info
   (and in which order) must be evaluated for the comparison. The last element of such array must be -1.
*/

int
compare_fingerprints(const clones a, const clones b)
{
    unsigned int block;
    for (block=0; block<blocks_per_fingerprint; block++) {
        fingerprint_type fa=discriminating_info[a].fingerprints[block];
        fingerprint_type fb=discriminating_info[b].fingerprints[block];
        PRINT_LOGn(3,"Comparing block %4u fingerprint %u %u\n", block, fa, fb);
        if (fa > fb)
            return 1;
        if (fa < fb)
            return -1;
    }
    return 0;
}




int
compare_discriminating_info (const clones a, const clones b, const int *order)
{
    unsigned int j;
    #ifndef NDEBUG
    if (VERBOSE>=3) {
        APPEND_LOGn(3,"Comparing ");
        print_info_clone(a,3);
        APPEND_LOGn(3," and ");
        print_info_clone(b,3);
        APPEND_LOGn(3,"\nOrder is: ");
        for(unsigned int i=0;order[i]>=0;i++)
            APPEND_LOGn(3,"%d ", order[i]);
        APPEND_LOGn(3,"*\n");
    }
    #endif


    APPEND_LOGn(3,"Result=");
    for (j=0; order[j]>=0; j++) {
//        PRINT_LOGn(3,"Comparing %3d %3d\n", j, order[j]);
        int cmp=0;
        if (0==order[j])
            cmp=compare_fingerprints(a,b);
        else {
            if (read_info_from_feature(a,order[j]) > read_info_from_feature(b,order[j]))
                cmp=1;
            else
                if (read_info_from_feature(a,order[j]) < read_info_from_feature(b,order[j]))
                    cmp=-1;
        }
        APPEND_LOGn(3,"%d ", cmp);
        if (cmp!=0) {
            APPEND_LOGn(3,"\n");
            return cmp;
        }
    }
    APPEND_LOGn(3,"\n");
    return 0;
}


/* Copyright (c) 2007 the authors listed at the following URL, and/or
the authors of referenced articles or incorporated external code:
http://en.literateprograms.org/Merge_sort_(C)?action=history&offset=20060514200945

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Retrieved from: http://en.literateprograms.org/Merge_sort_(C)?oldid=4743
*/
/*
   Besides the clones to be compared, the function receives a pointer to an array stating which discriminating_info
   (and in which order) must be evaluated for the comparison. The last element of such array must be -1.
   Such array will be passed untouched to compare_discriminating_info
*/

void
mergesort_clones(unsigned int lower, unsigned int size, clones * temp, const int *order) {
    unsigned int sorted_ok=1;
    unsigned int i1=0;
    unsigned int i2=size/2;
    unsigned int tempi=0;
    clones i;
    /**
       First check if the array is already sorted
    */

    PRINT_LOGn(3,"mergesort: %5d, %5d\n", lower, size);
    for (i=1; i<size; i++) {
        PRINT_LOGn(3,"mergesort: comparing %5d, %5d\n", lower+i-1, lower+i);
        if (compare_discriminating_info(sorted_clones[lower+i-1],sorted_clones[lower+i],order )>0) {
            sorted_ok=0;
            break;
        }
    }
    if (sorted_ok>0) {
        PRINT_LOGn(3,"mergesort: Sorted %d\n", sorted_ok);
        print_info_sorted_clones(lower,size+lower-1,3);
        return;
    }
    PRINT_LOGn(3,"mergesort: sorting\n");

    /*
      we need to sort recursively the array
    */
    mergesort_clones(lower, size/2, temp, order);
    mergesort_clones(lower+size/2, size - size/2, temp, order);
    while (i1 < size/2 && i2 < size) {
      if (compare_discriminating_info(sorted_clones[lower+i1],sorted_clones[lower+i2], order)<0) {
            temp[tempi] = sorted_clones[lower+i1];
            i1++;
        } else {
            temp[tempi] = sorted_clones[lower+i2];
            i2++;
        }
        tempi++;
    }

    for (;i1 < size/2;i1++, tempi++) {
        temp[tempi] = sorted_clones[lower+i1];
    }
    for (;i2 < size;i2++, tempi++) {
        temp[tempi] = sorted_clones[lower+i2];
    }

//    memcpy(temp+tempi, temp, (size+size/2-i1-i2)*sizeof(clones));


    for (i2=0;i2 < size;i2++) {
        sorted_clones[lower+i2] = temp[i2];
    }

    #ifndef NDEBUG
    PRINT_LOGn(3,"End of mergesort\nOrder: ");
    for(unsigned int j=0;order[j]>=0;j++) {
        APPEND_LOGn(3,"%d ", order[j]);
    }
    APPEND_LOGn(3,"*\n");
    print_info_sorted_clones(lower,size+lower-1,3);
    PRINT_LOGn(3,"Lower i     sorted A           B\n");
    for (i=1; i<size; i++) {
        PRINT_LOGn(3,"%5d %5d %5d\n", lower, i, sorted_clones[lower+i]);
        if (compare_discriminating_info(sorted_clones[lower+i-1],sorted_clones[lower+i], order)>0) {
            PRINT_FATAL("Error in mergesort %5d %5d %5d\n",lower, i, sorted_clones[lower+i]);
            abort();
        }
    }
    #endif
}


void
invert_array(clones *c) {
    unsigned int i;
    clones temp[number_clones];
    memcpy(temp, c, number_clones * sizeof(clones));
    for (i=0; i<number_clones; i++)
        c[temp[i]]=i;
}

/**
   The function fingerprint receives a block of a feasibile solution and a clone,
   returning the associated fingerprint.
*/
fingerprint_type
fingerprint_single_block(t_solutions my_solution, clones my_clone, unsigned int number_probes_block)
{
    fingerprint_type return_value=0;
    probes i;
    PRINT_LOGn(3,"Fingerprint: max_linear_response=%d\n", max_linear_response);
    APPEND_LOGn(3,"Fingerprint: %d=", my_clone);
    for (i=0; i<number_probes_block; i++) {
        return_value*=(max_linear_response+1);
        return_value+=read_packed_occurrences(my_clone,my_solution[i]);
        APPEND_LOGn(3,"%u:%d|", return_value, read_packed_occurrences(my_clone,my_solution[i]));
    }
    APPEND_LOGn(3,"\n");
    APPEND_LOGn(3,"Fingerprint: computed %u\n", return_value);

    return(return_value);
}

/**
   The function to update a complete fingerprint, even if spanning more than one block
*/

void
update_fingerprint(t_solutions my_solution)
{
//    unsigned int new_value, old_value;
//    unsigned long long int m = (unsigned long long int) pow(max_linear_response+1,my_probe-1);
    unsigned int block=0;
    clones c;
    unsigned int l,u=0;


    for(l=0,u=block_length-1; l<number_probes; l+=block_length,u+=block_length,block++) {
        if (u>=number_probes) {
            u=number_probes-1;
        }
        for (c=0;c<number_clones;c++) {
            unsigned int r=u-l+1;
            discriminating_info[c].fingerprints[block]=fingerprint_single_block(my_solution+l,c,r);
        }
    }
}

char*
reverse_fingerprint(clones clone, t_solutions sol, char s[])
{
    probes i=0;
    for (i=0;i<number_probes;i++) {
        s[i]='0'+(char) read_packed_occurrences(clone, sol[i]);
    }
    s[number_probes]='\0';
    return s;
}


costs
compute_cost(t_solutions solution) {
    costs cost=0;
    clones *temp;
    unsigned int size=1;
    int clones_order[]={ 0,  -1};
    char *s;
    unsigned int level;
    clones i;
    int inside_otu_order[]={ HIERARCHY_LEVELS, 0, -1};
    #ifndef NDEBUG
    t_solutions original_solution;

    original_solution=calloc((size_t) number_probes, sizeof(probes));
    if (original_solution==NULL) {
        PRINT_FATAL("Insufficient memory\n");
        abort();
    }
    memcpy(original_solution, solution, number_probes * sizeof (probes));
    #endif

    temp=calloc((size_t) number_clones, sizeof(clones));
    if (temp==NULL) {
        PRINT_FATAL("Insufficient memory\n");
        abort();
    }
    s=calloc((size_t) number_probes+1, sizeof(char));
    if (s==NULL) {
        PRINT_FATAL("Insufficient memory\n");
        abort();
    }

    update_fingerprint(solution);
    mergesort_clones(0,number_clones,temp,clones_order);


    /*
      The cost I am computing here is the number of pairs of clones sharing a common
      fingerprint, multiplied by penalties[0]
    */
    PRINT_LOGn(2,"COST: Step 1\n");
    APPEND_LOGn(2,"Clone Sorted_clone Fingerprint Features\n");
    APPEND_LOGn(2,"     0 %6u ",sorted_clones[0]);
    print_info_clone(sorted_clones[0],2);
    APPEND_LOGn(2,"\n");
    for (i=1; i<number_clones; i++) {
        APPEND_LOGn(2,"%6u %6u ",i, sorted_clones[i]);
        print_info_clone(sorted_clones[i],2);

        if (compare_fingerprints(sorted_clones[i],sorted_clones[i-1])==0) {
                cost+=(unsigned long long int) penalties[0]*size;
                APPEND_LOGn(2,"**");
                ++size;
        } else
            size=1;
        APPEND_LOGn(2," size=%d\n", size);
    }
    free(s);
    PRINT_LOGn(2,"COST: step 1 %lld\n", cost);




    /* compute an additional component of the cost function,
       equal to the number of pairs of distinct OTUs, genera ... sharing a any given
       fingerprint
    */
    /* NEW COST */
    PRINT_LOGn(0,"COST: before 2: %10lld\n", cost);
    APPEND_LOGn(2,"Clone Sorted_clone Fingerprint Features\n");
    for(level=1;level<=HIERARCHY_LEVELS;level++) {
        int level_order[]={ 0, (int) level, -1};
        mergesort_clones(0,number_clones,temp,level_order);
        size=1;

        PRINT_LOGn(3,"Level=%2d Cost=%12lld\n", level, penalties[level]);
        APPEND_LOGn(2,"Clone Sorted_clone Fingerprint Features\n");
        APPEND_LOGn(2,"    0 ");
        print_info_clone(sorted_clones[0],2);
        APPEND_LOGn(2,"\n");
        for (i=1; i<number_clones; i++) {
            APPEND_LOGn(2,"%5d ", i);
            print_info_clone(sorted_clones[i],2);

            if (compare_fingerprints(sorted_clones[i],sorted_clones[i-1])!=0) {
                size=1;
            } else {
                if (read_info_from_feature(sorted_clones[i],(int) level)!=read_info_from_feature(sorted_clones[i-1],(int) level)) {
                    cost += (costs) size*penalties[level];
                    ++size;
                    APPEND_LOGn(2,"**");
                    }
            }
            APPEND_LOGn(2," Size=%d\n", size);
        }
    }
    PRINT_LOGn(2,"Cost after 2: %10lld\n", cost);

    /*
      Compute an additional part of the cost that considers the number of distinct fingerprints
      in each OTU
    */

    mergesort_clones(0,number_clones,temp,inside_otu_order);
    size=1;
    PRINT_LOGn(0,"COST: before 3: %10lld\n", cost);
    APPEND_LOGn(2,"Clone Sorted_clone Fingerprint Features\n");
    APPEND_LOGn(2,"    0 ");
    print_info_clone(sorted_clones[0],2);
    APPEND_LOGn(2,"\n");
    for (i=1; i<number_clones; i++) {
        APPEND_LOGn(2,"%5d ", i);
        print_info_clone(sorted_clones[i],2);

        if (read_info_from_feature(sorted_clones[i],HIERARCHY_LEVELS)==read_info_from_feature(sorted_clones[i-1],HIERARCHY_LEVELS)) {
            /* we are in the same OTU */
            if (compare_fingerprints(sorted_clones[i],sorted_clones[i-1])!=0) {
                /* we have a different (distinct) fingerprint */
                cost += (costs) size*penalty_otu;
                ++size;
                APPEND_LOGn(2,"**");
            } // else: same fingerprint, same OTU => nothing to do
        } else {
            /* we are in a new OTU */
               size=1;
        }
        APPEND_LOGn(2," Size=%d\n", size);
    }
    PRINT_LOGn(0,"Cost final: %10lld\n", cost);


    /** TODO
        1. add a component to the objective function taking into account the Hamming distance between the probes
        2. add a component to the objective function taking into account the number of 1s in the fingerprints
    */

    #ifndef NDEBUG
    probes p;
    for(p=0;p<number_probes;p++) {
        if (original_solution[p]!=solution[p]) {
            PRINT_FATAL("solution %u has changed \n", p);
        }
    }
    free(original_solution);
    #endif


    free(temp);
    return cost;
}


/**
   The function random_range(int lowerbound, int upperbound) computes a
   random integer between lowerbound and upperbound,  extremes included
*/

int random_range(int lower_bound, int upper_bound)
{
    float temp_float;
    int temp_int;
    if (lower_bound > upper_bound)
        return -1;
    do {
        temp_float = (float) (rand() / (RAND_MAX + 1.0));
        temp_int = (int) lower_bound + (upper_bound - lower_bound + 1) * temp_float;
    } while (temp_int < lower_bound || temp_int > upper_bound);
    return (temp_int);
}

/**
   In some cases computing the function
   exp$(\frac{ |\Delta_S| -  |\Delta_{S'}|}{t}) \}$ may be the
   bottleneck. So we move it to a distinct function to have the
   possibility of chainging the implementation, if needed.
*/
float
lookup_exp(float my_diff, float my_temp)
{
    return ((float) exp(-my_diff/my_temp));
}
/**
   The function which_symbol(char search) gives the integer
   corresponding to a given character, looking up in the matrix alphabet~\label{alphabet}
*/

unsigned int
which_symbol(char char_to_search)
{
    unsigned int j = 0;
    const char alphabet[]="ACGT";

    while (char_to_search != alphabet[j] && j < MAX_ALPHABET_SIZE)
        j++;
    if (j == MAX_ALPHABET_SIZE) {
        int i;
        fprintf(stderr, "Looking for char *%c*\n", char_to_search);
        for (i=0;i< MAX_ALPHABET_SIZE; i++) {
            fprintf(stderr, "*%c*", alphabet[i]);
        }
        fprintf(stderr, "\n");
        PRINT_FATAL("FATAL: wrong char\n");
        abort();
    }
    return(j);
}

/**

   Since we are dealing with DNA it is straightforward to encode each
   string of $k$ symbols into an integer from $0$ to $4^k-1$, as done
   in str2int.
*/
unsigned int
str2int(char *my_probe)
{
    unsigned int number = 0;
    unsigned int i = 0, j, l;
    for (l = (unsigned int) strlen(my_probe); i < l; i++) {
        if (my_probe[i]!='\0' && my_probe[i]!='\n')
        {
            j = which_symbol(my_probe[i]);
            number *= MAX_ALPHABET_SIZE;
            number += j;
        }
    }
    if (number > max_search_space) {
        fprintf(stderr, "Error in encoding the probe\n");
        PRINT_FATAL("Probe %s encoded as %6d, maximum %6d\n",
                my_probe,  (int)  number, (int)  max_search_space);
        exit(EXIT_FAILURE);
    }
    return (number);
}

void
int2str(char *my_string, unsigned int explicit_probe)
{
    int i;
    const char alphabet[]="ACGT";

    for (i = (int) length_probes - 1; i >= 0; i--) {
        my_string[i] = alphabet[explicit_probe % MAX_ALPHABET_SIZE];
        explicit_probe -= (explicit_probe % MAX_ALPHABET_SIZE);
        explicit_probe = explicit_probe / MAX_ALPHABET_SIZE;
    }
    my_string[length_probes] = '\0';
}


void
copy_probes(unsigned int how_many, probes *destination, probes *source)
{
//    for (unsigned int l = 0; l < how_many; l++) {
//        printf("%d: %12d: %12d\n", l, destination[l] , source[l]);
//        destination[l] = source[l];
//    }
    memcpy (destination, source, how_many * sizeof (probes));
}
/**

   Since we want to use the smallest possible amount of memory, so that
   we can deal with a large number of probes, we need to pack more than
   one occurrence in a word (32-bit on i386 architecture). Assuming that
   the maximum occurrence is 15, BITS_PER_ENTRY=4 bits suffice to
   store an occurrence, so PACKING_FACTOR=8 occurrences can be stored
   in a word (type unsigned int). BIT_MASK has $1$ in the
   BITS_PER_ENTRY least significant bits. A number
   of functions are devoted to the management of occurrences.

   new_feature initialize the array storing the fingerprint
*/

void
new_feature(features *f)
{
    PRINT_LOGn(0,"Creating new feature using %u blocks\n", blocks_per_fingerprint);
    f->fingerprints = (feature_type *) calloc((size_t) blocks_per_fingerprint, sizeof(feature_type));
    if (f->fingerprints == NULL) {
        PRINT_FATAL("Fatal error: memory not allocated\n");
        abort();
    }
}

/* K&R2 getbits function,
   get n bits from position p
   rightmost bit is at position 0 */
unsigned int
getbits( unsigned int x, unsigned int  p, unsigned int  n )
{
#ifdef S_SPLINT_S
    if (p+1<n)
        abort();
#endif
    return (x>> (p+1-n)) & ~((unsigned int) ~0 << n);
}
/* setbits: set n bits from position p
   from http://undefcode.tistory.com/34 */
unsigned int
setbits( unsigned int x, unsigned int p, unsigned int n, unsigned int  y )
{
#ifdef S_SPLINT_S
    if (p+1<n)
        abort();
#endif
    return ( x & ~( ~((unsigned int) ~0 << n ) << (p+1-n)) ) | ( (y & ~((unsigned int) ~0 << n )) << (p+1-n) );
}


/**
   The
   function read_packed_occurrences receives the of clone and
   of probe and  returns occ$(c,p)$


unsigned int
read_packed_occurrences(clones my_clone, probes my_probe)
{
    register unsigned int factor=ceil(number_candidate_probes/PACKING_FACTOR);
    register unsigned int index=my_clone+number_clones*getbits(my_probe,PACKING_FACTOR-1,PACKING_FACTOR);

    offset = my_probe & ( ~(((unsigned int) (~0)) << BITS_PER_ENTRY));
    return(((occurrences[my_clone+number_clones*(my_probe-offset)/PACKING_FACTOR]) >> (unsigned int) (BITS_PER_ENTRY*offset)));
}
*/

/**
   The
   function write_packed_occurrences receives the of clone and
   of probe and the value to assign to  occ$(c,p)$, and executes the assignment
void
write_packed_occurrences(clones my_clone, probes my_probe, unsigned int my_value)
{
    unsigned int offset,i;
    offset = my_probe & ( ~(((unsigned int) (~0)) << BITS_PER_ENTRY));
    i=occurrences[my_clone+number_clones*(my_probe-offset)/PACKING_FACTOR];
    i = i &(~(BIT_MASK << (unsigned int) (BITS_PER_ENTRY*offset)));
    occurrences[my_clone+number_clones*(my_probe-offset)/
                PACKING_FACTOR]= i+(my_value << (unsigned int) (BITS_PER_ENTRY*offset));

}
*/

 /*
   The function init_packed_occurrences receives the number of clones and
   of probes and initializes the data structure which will contain all
   occurrences.
*/
void
init_packed_occurrences()
{
    clones i;
    probes j;

    PRINT_LOGn(0,"Allocating memory ...\n");
    occurrences = (unsigned short int *) calloc((size_t) number_candidate_probes*number_clones, sizeof(unsigned short int));
    if (occurrences == NULL) {
        PRINT_FATAL("Couldn't allocate %12u uints\n", (unsigned int) (number_candidate_probes*number_clones));
        abort();
    }
    for(i=0;i<number_clones;i++) {
        for(j=0;j<number_candidate_probes;j++) {
            write_packed_occurrences(i,j,0);
        }
    }
    PRINT_LOGn(0,"OK\n");
}

/**
   The
   functions write_fingerprint, read_fingerprint, and init_features
   manages the fingerprint associated to each clone
*/
/* unsigned int
read_fingerprint(clones my_clone, probes my_probe)
{
    register unsigned int which_word,actual_word;

    which_word=(unsigned int) (my_probe/block_length);
    actual_word=(discriminating_info+my_clone)->fingerprints[which_word];
    return getbits(actual_word,block_length,block_length*which_word+my_probe-which_word*block_length);
}
*/
void
write_fingerprint(clones my_clone, probes my_probe, unsigned int my_value)
{
    unsigned int which_word,actual_word;
    which_word=(unsigned int) (my_probe/block_length);
    actual_word=(discriminating_info+my_clone)->fingerprints[which_word];
    (discriminating_info+my_clone)->fingerprints[which_word]=
        setbits(actual_word,block_length,block_length*which_word+my_probe-which_word*block_length,my_value);
}



 /* read_info_from_feature returns the value of the hierarchy (i.e. genus, otu, ...)
    possible values of level are 1 .. HIERARCHY_LEVELS
    level=0 is not valid for compatibility
 */
feature_type
read_info_from_feature(const clones c, int level)
{
    #ifndef NDEBUG
    if (level > HIERARCHY_LEVELS || 0>=level ) {
        PRINT_FATAL("level too large %u\n", level);
    }
    #endif
    return (discriminating_info+c)->hierarchy[level-1];
}

void
write_info_from_feature(const clones c, unsigned int level, feature_type value)
{
    #ifndef NDEBUG
    if (level > HIERARCHY_LEVELS || 0==level ) {
        PRINT_FATAL("level too large %u\n", level);
    }
    #endif
    (discriminating_info+c)->hierarchy[level-1]=value;
}
void
init_features()
{
    clones i;
    probes j;

    PRINT_LOGn(0,"Allocating memory ...\n");
    discriminating_info = (features *) calloc((size_t) number_clones, sizeof(features));
    if (discriminating_info == NULL) {
        PRINT_FATAL("Fatal error: memory not allocated\n");
        abort();
    }

    PRINT_LOGn(0,"Initializing\n");
    for(i=0;i<number_clones;i++) {
        new_feature(discriminating_info+i);
        for(j=0;j<number_probes;j++) {
            write_fingerprint(i,j,0);
        }
    }
    PRINT_LOGn(0,"OK\n");
}

void
debug_output_solution(t_solutions  my_solution)
{
    #ifndef NDEBUG
    probes k;
    PRINT_LOGn(0,"output final solution\n");
    for (k = 0; k < number_probes; k++) {
        APPEND_LOGn(0,"Probe %6d:", my_solution[k]);
        for (clones my_clone=0; my_clone<number_clones; my_clone++)
            APPEND_LOGn(0,"%d", read_packed_occurrences(my_clone,my_solution[k]));
        APPEND_LOGn(0," (fingerprint from packed)\n");
    }
    PRINT_LOGn(0,"Sorted Clones with fingerprints\n");
    for (clones my_clone=0; my_clone<number_clones; my_clone++)
        print_info(sorted_clones[my_clone],my_solution,0);
    #endif
}


unsigned int
find_expanded_probe(char *probe)
{
    unsigned int index;
    for (index=0; index<number_candidate_probes; index++) {
        PRINT_LOGn(0,"FIND_EXPANDED_PROBE: *%s*:*%s*\n",expanded_probe[index], probe);
        if (0 == strcmp(expanded_probe[index], probe)) {
            break;
        }
    }
    return index;
}

/**

   The simulated annealing techinique requires computing a random initial
   solution and computing a neighbor solution. This steps are
   accomplished by the Random Initial and Random Neighbor
   functions.
*/
void
determine_initial_solution(t_solutions my_probes)
{
    unsigned int l;
    /*
      If there is a file containing the good probes, read the file and store the
      probes at the beginning of the array containing the actual solution.

      Subsequent updates to the actual solution will never modify such probes.
    */

    if (good_probes_file_name != NULL) {
        FILE *fd_good_probes_file;
        /*@null@*/char *temp_string = NULL;
        unsigned int length_string=0;

        fd_good_probes_file  = fopen(good_probes_file_name, "r");
        if (fd_good_probes_file==NULL) {
            PRINT_FATAL("Problems in opening file of good probes\n");
            abort();
        }
        while (getline(&temp_string, &length_string, fd_good_probes_file) >=0 && temp_string!=NULL) {
            my_probes[number_good_probes]=find_expanded_probe(temp_string);
            if (my_probes[number_good_probes] >= number_candidate_probes) {
                PRINT_LOGn(0,"GOOD PROBES: Could not find good probe %s", temp_string);
            } else {
                ++number_good_probes;
                PRINT_LOGn(0,"GOOD PROBES: Found good probe n. %d %s", number_good_probes, temp_string);
            }
        }
        if (fclose(fd_good_probes_file)<0) {
            PRINT_FATAL("Problems in closing file of good probes\n");
        }
        PRINT_LOGn(0,"Read %d good probes from %s\n", number_good_probes, good_probes_file_name);
        /*
          if good_probes_file_name is NULL, then this part is never executed in subsequent
          iterations of the algorithm, even if computing different probe sets.
        */
        good_probes_file_name=NULL;
    }

    for (l = number_good_probes; l <number_probes; l++) {
        unsigned int duplicated=0;
        my_probes[l] =  (probes) random_range(0, (int) number_candidate_probes - 1);
        /*
          No duplicated probes in the initial solution
        */
        for(probes p=0;p<l;p++) {
            if (my_probes[l]==my_probes[p])
                duplicated=1;
            }
        l-=duplicated;
    }
    for (l = 0; l <number_probes; l++) {
        PRINT_LOGn(0,"DEBUG: Initial solution %3d: %6d\n", l, my_probes[l]);
    }

    PRINT_LOGn(0,"First solution: before update_fingerprint\n");
    debug_output_solution(my_probes);
    update_fingerprint(my_probes);
    PRINT_LOGn(0,"First solution: after update_fingerprint\n");
    debug_output_solution(my_probes);
}

/**

   Computing the initial temperature is critical in the effectiveness of
   the method. The initial temperature allows with probability .5 to
   climb any hill (that is a hill of maximum cost);
*/
float
determine_initial_temperature(void)
{
    return( (float) MAX_POSSIBLE_COST*(float)1.5);
}

/**
   The function Output Final Clustersl outputs the final solution, with each
   cluster on a line by itself, plus different informations.
*/
void
output_final(t_solutions my_solution)
{
    probes k;
    printf("Final solution has value %20lld\n",  gcost);
    for (k = 0; k < number_probes; k++) {
        printf("%3u: %9u=%s",  k+1, my_solution[k], expanded_probe[my_solution[k]]);
    }
    PRINT_LOGn(0,"Check Final solution has value (check) %20lld\n",  compute_cost(my_solution));

    printf ("\n");
    debug_output_solution(my_solution);
}

void
split_to_ints(char delimiter, char *original, unsigned int *split_ints,
              unsigned int max_number_elements)
{

    unsigned int number_components=0;
    char delims[3];
    char *result = NULL;
    delims[0]=delimiter;
    delims[1]='\n';
    delims[2]='\0';

    PRINT_LOGn(3,"DEBUG: original\n%s\n", original);
    for(result=strtok(original, delims); result != NULL && original[0]!= '\n'; result = strtok(NULL, delims)) {
        PRINT_LOGn(3,"DEBUG: original=%s\n", original);
        if (number_components>=max_number_elements) {
            PRINT_LOGn(0,"FATAL: number_components>=max_number_elements =>%6d>=%6d\n", number_components, max_number_elements);
            PRINT_LOGn(0,"result=%s*\n", result);
            exit(EXIT_FAILURE);
        }
        split_ints[number_components++] = (unsigned int) atoi(result);
        PRINT_LOGn(3,"number_components, element, result: %6d, %6d, %s\n",
                  number_components-1, split_ints[number_components-1], result);
    }
}



/**

   The scan_input function reads the occurrence matrix from standard
   input and set the appropriate variables. While the split function receives a
   string and returns the list of numbers obtained
   from the original string and separated by spaces.

*/
void
scan_input(void)
{
    clones k;
    unsigned int num_line, length_string=0;
    char *temp_string = NULL;
    unsigned int actual_probe, i;
    FILE *fd_input_file= fopen(input_matrix_file_name, "r");

    if (fd_input_file == NULL) {
        fprintf(stderr, "Could not open file **%s**\n", input_matrix_file_name);
        fprintf(stderr, "Error number %s\n", strerror(errno));
        exit(EXIT_FAILURE);
    }

    PRINT_LOGn(0,"SCAN_INPUT: begin\n");
    if (number_probes > MAXIMUM_NUMBER_PROBES_IN_SOLUTION) {
        fprintf(stderr, "The number of requested probes is too large\n");
        exit(EXIT_FAILURE);
    }

    if (getline(&temp_string, &length_string, fd_input_file) <0 || temp_string == NULL) {
        free(fd_input_file);
        PRINT_FATAL("Error in reading from standard input\n");
        abort();
    }
    number_clones =(unsigned int) atoi(temp_string);
    /* how many blocks are needed for storing each fingerprint? */
    block_length=(unsigned int) floor(log2((double) UINT_MAX+1));
    PRINT_LOGn(0,"block_length=%u\n", block_length);
    blocks_per_fingerprint=(unsigned int) ceil((double) number_probes/(double) block_length);
    PRINT_LOGn(0,"blocks_per_fingerprint=%u\n", blocks_per_fingerprint);
    init_packed_occurrences(number_clones, number_candidate_probes);
    init_features();
    PRINT_LOGn(0,"DEBUG: Number of clones: %6d\n", (int)  number_clones);
    sorted_clones=(clones *) calloc((size_t) (int) number_clones, sizeof(clones));
    for(clones c=0;c<number_clones;c++)
        sorted_clones[c]=c;

    expanded_probe=(char **) calloc((size_t)number_candidate_probes,sizeof(char *));
    if (expanded_probe == NULL) {
        fprintf(stderr, "Fatal error - memory not allocated %d\n", __LINE__);
        exit(EXIT_FAILURE);
    }
    PRINT_LOGn(0,"DEBUG: allocated expanded_probe\n");


    max_linear_response=0;
    for(num_line=0; num_line<number_candidate_probes;num_line++) {
/**
   each candidate probe consists of two input rows: the probe and the row of the probe/clone matrix
*/
        char *new_candidate_probe=NULL;
        unsigned int *values;
        char *values_row=NULL;

        values=calloc((size_t) number_clones, sizeof(unsigned int));
        if (values==NULL) {
            PRINT_FATAL("Insufficient memory\n");
            abort();
        }


        length_string=0;
        PRINT_LOGn(0,"Reading line %12d\n", num_line);


        if (getline(&new_candidate_probe, &length_string, fd_input_file) <0 || new_candidate_probe==NULL) {
            PRINT_FATAL("Error in reading probe from standard input: seq %6u of %6u\n", num_line, number_candidate_probes);
            abort();
        }
        if (0==num_line) {
/* First line: must recognize the length of each candidate probe */
            length_probes = (unsigned int) strlen(new_candidate_probe);
            max_search_space = (unsigned int) pow(MAX_ALPHABET_SIZE, (double) length_probes);
        }
/* Encode the k-mer into a comapct representation, stored in actual_probe */
        PRINT_LOGn(0,"Encoding line %12u\n", num_line);
        actual_probe = (unsigned int) num_line;
        expanded_probe[actual_probe] = (char *) calloc ((size_t) length_probes+1, sizeof(char));
        if (expanded_probe[actual_probe]==NULL) {
            PRINT_FATAL("problem Encoding line %12u\n",num_line);
            abort();
        }
        strcpy(expanded_probe[actual_probe], new_candidate_probe);
/* now read all values of the fingerprint matrix */
        length_string=0;
        if (getline(&values_row, &length_string, fd_input_file) <0 || values_row==NULL) {
            PRINT_FATAL("Error in reading row from standard input: seq %6u of %6u\n", num_line, number_candidate_probes);
            abort();
        }
        PRINT_LOGn(0,"Before split_to_ints %12d\n", num_line);
        PRINT_LOGn(3,"Line read: %s\n", values_row);
        split_to_ints(' ', values_row, values, number_clones);
        PRINT_LOGn(0,"After split_to_ints %12d\n", num_line);

        for (k = 0; k < number_clones; k++) {
            write_packed_occurrences(k, actual_probe, (unsigned short int) values[k]);
            if (max_linear_response < read_packed_occurrences(k, actual_probe))
                max_linear_response = read_packed_occurrences(k, actual_probe);
        }
        for (k = 0; k < number_clones; k++)
            APPEND_LOGn(3,"%u ",read_packed_occurrences(k, actual_probe));
        APPEND_LOGn(3,"\n");


        PRINT_LOGn(0,"After write %12d\n", num_line);
        free(values_row);
        free(values);
    }
    PRINT_LOGn(0,"MAX_LINEAR_RESPONSE = %d\n", max_linear_response);

    for (i=1; i<=HIERARCHY_LEVELS; i++) {
        unsigned int *temp_array=calloc((size_t) number_clones, sizeof(unsigned int));
        if (temp_array==NULL) {
            PRINT_FATAL("Insufficient memory\n");
            abort();
        }

        PRINT_LOGn(0,"DEBUG: Reading level %d discriminating  information\n", i);
        temp_string=NULL;
        length_string=0;
        if (getline(&temp_string, &length_string, fd_input_file) <0 || temp_string==NULL) {
            PRINT_FATAL("Error in reading level %u discriminating  information\n", i);
            abort();
        }
        split_to_ints(' ', temp_string, temp_array, number_clones);
        for (k=0; k<number_clones; k++) {
            write_info_from_feature(k,i,temp_array[k]);
            PRINT_LOGn(3,"Info n. %6d = %u\n", k, read_info_from_feature(k,(int) i));
        }
        free(temp_array);
    }
    PRINT_LOGn(0,"Read input file\n");
    if (fclose(fd_input_file) <0) {
        PRINT_FATAL("Error in closing input file\n");
    }
    if (sorted_clones == NULL) {
        PRINT_FATAL("FATAL: sorted_clones is null\n");
        abort();
    }
}





int
main(int argc, char **argv)
{
    unsigned int number_iteration_fixed_temperature;
    t_solutions best_actual_solution, actual_solution;
    costs best_actual_cost;
    unsigned int number_experiments, initial_seed;
    unsigned int i, total_iterations = 0,num_decrements;
    struct gengetopt_args_info args_info;
    if (cmdline_parser (argc, argv, &args_info) != 0) {
        PRINT_FATAL("Cannot parse arguments\n");
        exit(EXIT_FAILURE);
    }
    PRINT_LOGn(0,"DEBUG: Beginning computation\n");
    number_probes= (unsigned int) args_info.number_probes_arg;
    if (args_info.number_experiments_given>0)
        number_experiments =  (unsigned int) args_info.number_experiments_arg;
    else
        number_experiments = 1;
    number_candidate_probes =  (unsigned int) args_info.number_candidate_arg;
    if (args_info.number_iteration_fixed_temperature_given>0)
        number_iteration_fixed_temperature=  (unsigned int) args_info.number_iteration_fixed_temperature_arg;
    else
        number_iteration_fixed_temperature=1;
    if (args_info.steepness_given>0)
        beta= (unsigned int) args_info.steepness_arg;
    else
        beta=2;
    if (args_info.penalty_standard_given>0)
        penalties[0]= args_info.penalty_standard_arg;
    else
        penalties[0]=10;
    if (args_info.penalty_otu_given>0)
        penalties[3]= args_info.penalty_otu_arg;
    else
        penalties[3]=1;
    if (args_info.penalty_phylum_given>0)
        penalties[1]= args_info.penalty_phylum_arg;
    else
        penalties[1]=2;
    if (args_info.penalty_genus_given>0)
        penalties[2]= args_info.penalty_genus_arg;
    else
        penalties[2]=3;
    if (args_info.good_probes_file_given>0) {
        good_probes_file_name = (char *) calloc (1+strlen (args_info.good_probes_file_arg), (size_t) sizeof(char));
        if (good_probes_file_name == NULL) {
            PRINT_FATAL("Error in good probes file name\n");
            abort();
        }
        strcpy(good_probes_file_name, args_info.good_probes_file_arg);
    } else {
        number_good_probes = 0;
    }
    if (args_info.bad_probes_file_given>0) {
        bad_probes_file_name = (char *) calloc (1+strlen (args_info.bad_probes_file_arg), (size_t) sizeof(char));
        if (bad_probes_file_name == NULL) {
            PRINT_FATAL("Error in bad probes file name\n");
            abort();
        }
        strcpy(bad_probes_file_name,args_info.bad_probes_file_arg);
    }
    if (args_info.input_matrix_file_given>0) {
        input_matrix_file_name = (char *) calloc (1+strlen (args_info.input_matrix_file_arg), (size_t) sizeof(char));
        if (input_matrix_file_name == NULL) {
            PRINT_FATAL("Error in input matrix file name\n");
            abort();
        }
        strcpy(input_matrix_file_name,args_info.input_matrix_file_arg);
    }

    if (args_info.penalty_mixed_otu_given>0)
        penalty_otu= args_info.penalty_mixed_otu_arg;
    else
        penalty_otu=0;


    PRINT_LOGn(0,"ARGS: penalties[0]=%4lld\n", penalties[0]);
    PRINT_LOGn(0,"ARGS: penalties[1]=%4lld\n", penalties[1]);
    PRINT_LOGn(0,"ARGS: penalties[2]=%4lld\n", penalties[2]);
    PRINT_LOGn(0,"ARGS: penalties[3]=%4lld\n", penalties[3]);



    if (args_info.random_seed_given>0)
      initial_seed= (unsigned int) args_info.random_seed_arg;
    else
      initial_seed=(unsigned int) time(0);
    PRINT_LOGn(0,"Initial seed should be %8d\n", initial_seed);
    srand(initial_seed);


/**


   Now it is time to initialize all global variables, read the input,
   initialize all data structures.
*/

    if (number_probes < 1) {
        PRINT_FATAL("Incorrect number of probes\n");
        exit(EXIT_FAILURE);
    }

    fprintf(stderr,"Initial seed: %6d\n", (int) initial_seed);
    PRINT_LOGn(0,"Number of candidate probes: %6d\n", (int) number_candidate_probes);
    PRINT_LOGn(0,"Number of requested probes: %6d\n", (int)number_probes);
    PRINT_LOGn(0,"Number of experiments: %6d\n", (int)number_experiments);
    PRINT_LOGn(0,"Number iterations at a temperature: %6d\n", (int)number_iteration_fixed_temperature);
    PRINT_LOGn(0,"Steepness: %6d\n", (int)beta);
    PRINT_LOGn(0,"Penalty if different clones, same fingerprint: %6d\n", (int) penalties[0]);
    PRINT_LOGn(0,"Penalty if different fingerprints, same OTU: %6d\n", (int)penalties[3]);
    PRINT_LOGn(0,"Penalty if different fingerprints, same genus: %6d\n", (int)penalties[1]);
    PRINT_LOGn(0,"Penalty if different fingerprints, same phylum: %6d\n", (int)penalties[2]);

    if (args_info.test_given>0) {
        /**
           Run the tests
        */
        run_tests();
        exit(EXIT_SUCCESS);
    }


    scan_input();
    PRINT_LOGn(0,"DEBUG: input read\n");



/**

   Now we can initialize
   hash_cost_size that is the total number of allowed fingerprints.

*/
    actual_solution = (probes *) calloc((size_t) number_probes, sizeof(probes));
    if (actual_solution == NULL) {
        PRINT_FATAL("Fatal error - memory not allocated\n");
        exit(EXIT_FAILURE);
    }
    best_actual_solution = (probes *) calloc((size_t) number_probes, sizeof(probes));
    if (best_actual_solution == NULL) {
        PRINT_FATAL("Fatal error - memory not allocated\n");
        exit(EXIT_FAILURE);
    }

/**

   Now all preliminary stuff is done. It is time for the real algorithm,
   to be cycled for number_experiments times. We will return the best
   result obtained.

*/

    for (i = 1; i <= number_experiments; i++) {
/**

   The code of on experiments is the straightforward translation of the
   algorithm stated at the beginning.
*/
        unsigned int number_iterations = 0, pos_changed;
        probes j, prev_solution[number_probes];
        float temperature;


        determine_initial_solution(actual_solution);
        gcost=compute_cost(actual_solution);
        if (gcost < 0) {
            PRINT_FATAL("Overflow in computing the cost: it is necessary to use smaller penalties\n");
        }
        best_actual_cost=compute_cost(actual_solution);
        #ifndef NDEBUG
        if (gcost!=compute_cost(actual_solution) || gcost != best_actual_cost || best_actual_cost != compute_cost(actual_solution)) {
            PRINT_FATAL("Fatal Error in computing the cost of initial solution\n Gcost %12lld, best_actual_cost %12lld, actual cost %12lld\n", gcost, best_actual_cost, compute_cost(actual_solution));
            abort();
        }
        #endif
/*         for (unsigned int ppp=0; ppp<number_probes; ppp++) { */
/*             printf("%12d : %12d : %12d\n", (int) ppp, best_actual_solution[ppp],   actual_solution[ppp]); */
/*         } */
//        copy_probes(number_probes, best_actual_solution, actual_solution);
        memcpy (best_actual_solution, actual_solution, number_probes * sizeof (probes));

        PRINT_LOGn(0,"DEBUG:Cost of initial solution = %12lld\n", gcost);
        temperature=determine_initial_temperature();
        PRINT_LOGn(0,"DEBUG:Initial temperature = %10.10f\n", temperature);
        total_iterations = 0;

        for(num_decrements=0;num_decrements < NUMBER_COOLINGS; total_iterations++) {
            costs old_cost=gcost;
            float prob;

            bool different_probe=true; // true if the new probe is not in the previous solution
            #ifndef NDEBUG
            PRINT_LOGn(0,"SOLUTION 1: Gcost %12lld, old_cost %12lld, actual cost %12lld\n",
                      gcost, old_cost, compute_cost(actual_solution));
            if (old_cost!=gcost) {
                PRINT_LOGn(0,"SOLUTION 2: Incorrect assignment old_cost=gcost\n");
                PRINT_LOGn(0,"SOLUTION 3: Gcost %12lld, old_cost %12lld\n",
                      gcost, old_cost);
            }

            if (old_cost!=compute_cost(actual_solution)) {
                PRINT_LOGn(0,"SOLUTION 4: Error in computing the cost of old solution\n");
                PRINT_LOGn(0,"SOLUTION 5: Gcost %12lld, old_cost %12lld, actual cost %12lld\n",
                      gcost, old_cost, compute_cost(actual_solution));
                abort();
            } else {
                PRINT_LOGn(0,"SOLUTION 6: Computation of old_cost is correct\n");
            }
            #endif

            PRINT_LOGn(0,"SOLUTION 7: new solution\n");
            /*             for (unsigned int j=0;j<number_probes; j++) */
            /*                 prev_solution[j]=actual_solution[j]; */
            memcpy (prev_solution, actual_solution, number_probes * sizeof (probes));

            pos_changed=neighbor_solution(actual_solution);
            for (j=0;j<number_probes; j++) {
                if (prev_solution[j] == actual_solution[pos_changed]) {
                    different_probe=false;
                }
                PRINT_LOGn(0,"SOLUTION 8: Probe %2d=%6d\n",j,actual_solution[j]);
            }
            gcost=compute_cost(actual_solution);
            if (gcost < 0) {
                PRINT_FATAL("Overflow in computing the cost: it is necessary to use smaller penalties\n");
            }

            PRINT_LOGn(0,"SOLUTION 9: probe %6d changed from %6d to %6d\n", pos_changed, prev_solution[pos_changed], actual_solution[pos_changed]);
            prob=lookup_exp((float)  (gcost-old_cost), temperature);
            if (prob-1 >FLT_EPSILON)
                prob=1;
            PRINT_LOGn(0,"SOLUTION 10: old cost/new cost %12lld/%12lld\n", old_cost, gcost);
            PRINT_LOGn(0,"SOLUTION 11: Probability of moving was %2.10f\n", prob);

            if (gcost < best_actual_cost && different_probe && (old_cost >= gcost ||
                (float) rand()/RAND_MAX-lookup_exp((float) (gcost-old_cost), temperature) <
                FLT_EPSILON)) {
                // acceptance of new solution
                PRINT_LOGn(0,"SOLUTION 12a: Going to new solution\n");
                best_actual_cost=gcost;
                //                    copy_probes(number_probes,best_actual_solution, actual_solution);
                memcpy (best_actual_solution, actual_solution, number_probes * sizeof (probes));
            } else  {
                // go back to previous solution
                PRINT_LOGn(0,"SOLUTION 12b: Reverting probe %6d to prev value %6d from %6d\n", pos_changed, prev_solution[pos_changed], actual_solution[pos_changed]);
                actual_solution[pos_changed]=prev_solution[pos_changed];
                update_fingerprint(actual_solution);

                #ifndef NDEBUG
                if (old_cost!=compute_cost(actual_solution)) {
                    PRINT_LOGn(0,"SOLUTION 13: Gcost %12lld, old_cost %12lld, actual cost %12lld, previous cost %12lld\n",
                           gcost, old_cost, compute_cost(actual_solution),  compute_cost(prev_solution));
                    PRINT_LOGn(0,"SOLUTION 14: Error #R001 in reverting to old solution\n");
                    PRINT_LOGn(0,"SOLUTION 15:  j previous actual\n");
                    for (unsigned int j=0; j<number_probes; j++) {
                        PRINT_LOGn(0,"SOLUTION 16: %3d %6d %6d", j, prev_solution[j], actual_solution[j]);
                        if (prev_solution[j] != actual_solution[j])
                            PRINT_LOGn(0,"*");
                        PRINT_LOGn(0,"\n");
                    }
                    abort();
                }
                #endif
                gcost=old_cost;
            }
            number_iterations++;

            if (number_iterations >= number_iteration_fixed_temperature) {
                temperature *= ((float) beta) / (beta + temperature);
                PRINT_LOGn(0,"SOLUTION 17: temperature=%10.10f\n", temperature);
                num_decrements++;
                number_iterations = 0;
            }
        }
        PRINT_LOGn(0,"SOLUTION 18: Actual final temperature %10.10f\n", temperature);
        PRINT_LOGn(0,"SOLUTION 19: Actual final cost %20lld\n", gcost);
        output_final(best_actual_solution);
        if(gcost!=compute_cost(best_actual_solution)) {
            PRINT_FATAL("FATAL: error in computing the cost of the final solution\n");
            abort();
        }
    }

/**
   Now all experiments have completed. Outputting the best result.
*/
    exit(EXIT_SUCCESS);
}

/**

   {\small
   \begin{thebibliography}{9}
   \bibitem{ismb2001}
   J.~Borneman, M.~Chrobak, G.~Della Vedova, A.~Figueroa, T.~Jiang
   Probe Selection Algorithms with Applications in the Analysis of Microbial Communities
   \textit{Bioinformatics} 17(Suppl.~1): 39--48, 2001.
   \end{thebibliography}
   }
   \end{document}

*/
